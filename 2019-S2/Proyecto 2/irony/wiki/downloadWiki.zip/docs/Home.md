**Irony** is a development kit for implementing languages on .NET platform. Unlike most existing yacc/lex-style solutions Irony does not employ any scanner or parser code generation from grammar specifications written in a specialized meta-language. In Irony the target language grammar is coded directly in c# using operator overloading to express grammar constructs. Irony's scanner and parser modules use the grammar encoded as c# class to control the parsing process. See the [expression grammar sample](expression-grammar-sample) for an example of grammar definition in c# class, and using it in a working parser. 

**Download contents**
The download zip contains core Irony libraries implementing a parsing engine, an interpreter, a number of sample grammars, unit test projects, and Grammar Explorer tool for viewing and debugging your languages (see picture below). 
We provide multiple sample grammars for languages like GW Basic, Java, c#, Scheme, SQL, JSON and some others. Irony includes a ready-to-use expression evaluator that can be easily plugged-in into a .NET application.

![](Home_irony_GrammarExplorer.jpg)

**System Requirements**
Windows 7, .NET Framework 4.0, Visual Studio 2010

**Irony on the Web**
[Irony presentation at LangNET 2009 symposium](http://langnetsymposium.com/)
[Scott Hanselman about Irony.](http://www.hanselman.com/blog/TheWeeklySourceCode59AnOpenSourceTreasureIronyNETLanguageImplementationKit.aspx) 
[Writing your first Domain-Specific Language](http://www.codeproject.com/KB/recipes/YourFirstDSL.aspx)
[A Google-like Full Text Search engine based on Irony parser.](http://www.sqlservercentral.com/articles/Full-Text+Search+(2008)/64248/)
[Writing your first Visual Studio Language Service](http://www.codeproject.com/KB/recipes/VSLanguageService.aspx)
[Writing a calculator in c# using Irony](http://blog.miraclespain.com/archive/2009/Oct-07.html)
[Shakespeare Language Compiler using Irony](https://irony.codeplex.com/discussions/456720)

**More information**
[Expression Grammar sample](Expression-Grammar-sample)
[Contributors](Contributors)
[Willing to Contribute?](ContribProjects)
[Demo Running Instructions](Demo-Running-Instructions)
[Wikibook: Irony - Language Implementation Kit](http://en.wikibooks.org/wiki/Irony_-_Language_Implementation_Kit) - everybody is welcome to contribute.

**My blog and other projects**
[Irony blog](http://irony-roman.blogspot.com/)
[VITA Application Framework](http://vita.codeplex.com)