**Demo instructions**
* If you are interested in Silverlight version of Irony, make sure you install Silverlight tools before you open Irony solution - see instructions below.
* Open Irony_All.sln solution file in Visual Studio.
* If you are not interested in Silverlight development, remove the project "100.IronySilverlight" from the solution. 
* Right-click on the project "030.Irony.GrammarExplorer" and select "Set as StartUp project" from the context menu.
* Click Run button on toolbar (F5). Grammar Explorer Window opens.
* **Important: if you are launching the Grammar Explorer for the first time after downloading Irony and if you see that Grammars combobox is not empty, then clear it: click on the button next to the combobox and select "Remove all"**
* If the Grammar combobox on top is empty, click on the button next to it (or right-click the combobox) and select "Add grammar" command. In the file-open window that appears, navigate to (root)\Irony.Samples\bin\debug folder and select Irony.Samples.dll. Application will popup a small window with a list of grammars in selected assembly. Leave all lines checked and click "OK". The newly added grammars will appear in the grammar combobox.  
* Select a grammar (language) in top combo-box. If you see exception window with error popping up, then go back to previous step and remove all old grammars by selecting "Remove all" command.
* Browse form tabs to see grammar data. 
* To parse source code sample, switch to "Test" tab. Click "Load..." button on top of the form. Open file dialog opens.
* Navigate to <root>\Irony.Samples\SourceSamples folder. Select source file appropriate for currently selected grammar. 
* Source file contents are loaded into text area in the form. Click Parse button on top of the form. 
* The Output Syntax Tree control on the right (in Results tab in the right tab control) would contain a parsed syntax tree.
* If button "Run" is enabled, click it to execute the code. The results are shown in the Output window at the bottom of the form. For Expression Evaluator grammar, the output is the result of the last expression or assignment. Interpreter for Scheme can execute more complex programs found in SourceSamples\Scheme subfolder.  
* Alternatively you can paste or type your own sample program into source text area. 
* Repeat for other selections in the Grammar combobox.
Note that Grammar Explorer restores your last language selection and source sample after you close/restart the form. 

**Installing Silverlight tools**
* If you are going to use Team Foundation Server Client, install it from here: 
  http://www.microsoft.com/downloads/details.aspx?displaylang=en&FamilyID=0ed12659-3d41-4420-bbb0-a46e51bfca86
* Install Visual Studio 2010
* Install Silverlight 4 Tools (from [http://www.microsoft.com/download/en/details.aspx?id=18149](http://www.microsoft.com/download/en/details.aspx?id=18149))


