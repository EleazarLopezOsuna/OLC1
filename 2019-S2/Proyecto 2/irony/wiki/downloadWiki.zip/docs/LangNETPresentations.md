## Lang.NET 2008
On Jan 28-30, 2008, Microsoft hosted a symposium on dynamic and .NET languages: [Lang.NET 2008](http://www.langnetsymposium.com/). 
I (Roman Ivantsov, Irony project coordinator) made two presentations there:
* Parsing with Irony
* ERP Language Challenges

Slides in .ppt format are available here:
[Parsing with Irony](LangNETPresentations_LangNetTalk_Irony.ppt)
[ERP Language Challenges](LangNETPresentations_LangNetTalk_ERP.ppt)  

The first talk was about Irony project itself; the second presentation was about ERP systems and it explained the origins of Irony project. _(ERP - Enterprise Resource Planning - big information systems that run entire business of large corporations and governments)_. 
  
