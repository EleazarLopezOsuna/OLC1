**Features to complete for the first release**
# Implement support for robust error reporting and recovery mechanisms in target parsers - 
# Implement global symbol table
# Complete the set of standard Terminal classes for lexeme types found in popular programming languages - numbers, literals, identifiers, etc. 
# Build a set of built-in AstNode classes for common syntax constructs
# Create NUnit tests for all testable units
# Implement interpreter mode support for simple procedural programs. Built-in AST node classes would have Evaluate method, so that the entire program can be executed by calling Evaluate on root node. The non-procedural OOP-style programs would require non-trivial Runtime infrastructure, which will be built later. 
# Create interactive console

**Further development**
# Create introductory documentation and embedded XML documentation for major components. 
# Provide support for LALR(1.5) parsing with extra token preview on shift. Some languages, like Scheme, seem to need this extension
# Implement robust support for AST tree analysis and processing. Hopefully no visitor pattern, but something like multiple-type dispatch.  
# Advanced AST tree analysis - type checking and inference, optimization, etc. 
# Create core runtime infrastructure supporting dynamic object model, maybe something along these lines: [http://piumarta.com/pepsi/objmodel2.pdf](http://piumarta.com/pepsi/objmodel2.pdf).
# .NET interoperability support
# Build more realistic (than current samples) reference implementations for one or two programming languages
# AST-to-MSIL compilation support. 
# Build _GrammarData_ code serializer, so that derived grammar data doesn't need to be rebuilt from scratch each time the compiler starts. Instead, _GrammaData_ object will be deserialized from code similar to .NET Windows Forms. 
# CodeDom and Visual Studio integration support
