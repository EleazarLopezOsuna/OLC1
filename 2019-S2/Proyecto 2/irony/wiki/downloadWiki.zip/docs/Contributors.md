**Contributors**

The following people made contributions to Irony project, and I would like to express my gratitude to them:

**Alexey Yakovlev (yallie)** 
* Contributed Refal programming language implementation.
* Implemented auto-reloading on compile of grammar assemblies in Grammar Explorer.
* Implemented LineContinuationTerminal.
* Implemented semi-automatic parser conflict resolution from token preview (08/02/2011 - currently in review).
  
**William Horner (wmh)**: contributed implementation of auto-compiled delegates for AST node creation.
**Philipp Serr**: completed NumberLiteral implementation with advanced features for c#, python, VB
CodePlex user **notmasteryet**: improved GwBasic grammar to make it match the syntax rules of GwBasic
**Benjamen Morrison**: created an implementation of Language Services for Visual Studio integration based on Irony.   This code is not a part of Irony codebase (yet), but you can find it in the article in CodeProject.com
**Michael Coles** - created SearchGrammar for converting Google-like search queries into MS SQL Server full-text search syntax. The code is used in his book "Pro Full-Text Search in SQL Server 2008".
**Kirill Osenkov**: created IronySilverlight, Irony version for Silverlight environment
